To get started execute the following command:

./run.sh

This will run a basic test on your local machine.